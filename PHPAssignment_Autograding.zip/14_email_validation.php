<?php
// TODO: Implement function for email validation

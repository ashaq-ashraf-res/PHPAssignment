<?php
// TODO: Implement function for factorial

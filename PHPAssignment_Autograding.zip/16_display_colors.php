<?php
// TODO: Implement function for display colors

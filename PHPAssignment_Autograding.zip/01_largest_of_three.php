<?php
// TODO: Implement function for largest of three

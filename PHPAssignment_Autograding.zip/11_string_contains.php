<?php
// TODO: Implement function for string contains

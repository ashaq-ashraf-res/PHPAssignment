<?php
// TODO: Implement function for replace the

<?php
// TODO: Implement function for even numbers

<?php
// TODO: Implement function for reverse string

<?php
// TODO: Implement function for remove whitespace

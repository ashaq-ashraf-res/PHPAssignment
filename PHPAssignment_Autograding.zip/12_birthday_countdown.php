<?php
// TODO: Implement function for birthday countdown

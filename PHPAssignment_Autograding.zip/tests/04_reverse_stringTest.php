<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../04_reverse_string.php';

class ReverseStringTest extends TestCase {
    public function testExample() {
        // TODO: Write test for reverse string
        $this->assertTrue(true);
    }
}

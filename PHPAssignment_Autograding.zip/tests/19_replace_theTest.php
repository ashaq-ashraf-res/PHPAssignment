<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../19_replace_the.php';

class ReplaceTheTest extends TestCase {
    public function testExample() {
        // TODO: Write test for replace the
        $this->assertTrue(true);
    }
}

<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../15_even_numbers.php';

class EvenNumbersTest extends TestCase {
    public function testExample() {
        // TODO: Write test for even numbers
        $this->assertTrue(true);
    }
}

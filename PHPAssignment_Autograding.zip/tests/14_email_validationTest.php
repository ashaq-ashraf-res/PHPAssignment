<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../14_email_validation.php';

class EmailValidationTest extends TestCase {
    public function testExample() {
        // TODO: Write test for email validation
        $this->assertTrue(true);
    }
}

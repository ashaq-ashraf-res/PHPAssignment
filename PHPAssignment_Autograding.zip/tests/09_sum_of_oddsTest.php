<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../09_sum_of_odds.php';

class SumOfOddsTest extends TestCase {
    public function testExample() {
        // TODO: Write test for sum of odds
        $this->assertTrue(true);
    }
}

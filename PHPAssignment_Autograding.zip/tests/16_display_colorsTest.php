<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../16_display_colors.php';

class DisplayColorsTest extends TestCase {
    public function testExample() {
        // TODO: Write test for display colors
        $this->assertTrue(true);
    }
}

<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../01_largest_of_three.php';

class LargestOfThreeTest extends TestCase {
    public function testExample() {
        // TODO: Write test for largest of three
        $this->assertTrue(true);
    }
}

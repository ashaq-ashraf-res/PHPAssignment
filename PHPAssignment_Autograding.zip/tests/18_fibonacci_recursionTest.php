<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../18_fibonacci_recursion.php';

class FibonacciRecursionTest extends TestCase {
    public function testExample() {
        // TODO: Write test for fibonacci recursion
        $this->assertTrue(true);
    }
}

<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../12_birthday_countdown.php';

class BirthdayCountdownTest extends TestCase {
    public function testExample() {
        // TODO: Write test for birthday countdown
        $this->assertTrue(true);
    }
}

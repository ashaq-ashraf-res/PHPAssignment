<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../08_remove_whitespace.php';

class RemoveWhitespaceTest extends TestCase {
    public function testExample() {
        // TODO: Write test for remove whitespace
        $this->assertTrue(true);
    }
}

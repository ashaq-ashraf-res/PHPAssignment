<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../07_sort_array.php';

class SortArrayTest extends TestCase {
    public function testExample() {
        // TODO: Write test for sort array
        $this->assertTrue(true);
    }
}

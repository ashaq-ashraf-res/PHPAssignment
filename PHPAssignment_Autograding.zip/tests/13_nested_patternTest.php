<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../13_nested_pattern.php';

class NestedPatternTest extends TestCase {
    public function testExample() {
        // TODO: Write test for nested pattern
        $this->assertTrue(true);
    }
}

<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../11_string_contains.php';

class StringContainsTest extends TestCase {
    public function testExample() {
        // TODO: Write test for string contains
        $this->assertTrue(true);
    }
}

<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../05_is_lowercase.php';

class IsLowercaseTest extends TestCase {
    public function testExample() {
        // TODO: Write test for is lowercase
        $this->assertTrue(true);
    }
}

<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../17_language_greeting.php';

class LanguageGreetingTest extends TestCase {
    public function testExample() {
        // TODO: Write test for language greeting
        $this->assertTrue(true);
    }
}

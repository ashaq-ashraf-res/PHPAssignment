<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../03_prime_check.php';

class PrimeCheckTest extends TestCase {
    public function testExample() {
        // TODO: Write test for prime check
        $this->assertTrue(true);
    }
}

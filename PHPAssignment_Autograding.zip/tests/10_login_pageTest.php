<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../10_login_page.php';

class LoginPageTest extends TestCase {
    public function testExample() {
        // TODO: Write test for login page
        $this->assertTrue(true);
    }
}

<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../06_palindrome_check.php';

class PalindromeCheckTest extends TestCase {
    public function testExample() {
        // TODO: Write test for palindrome check
        $this->assertTrue(true);
    }
}

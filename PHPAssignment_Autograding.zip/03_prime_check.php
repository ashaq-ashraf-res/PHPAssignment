<?php
// TODO: Implement function for prime check

<?php
// TODO: Implement function for login page

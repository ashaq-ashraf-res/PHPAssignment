<?php
// TODO: Implement function for sum of odds

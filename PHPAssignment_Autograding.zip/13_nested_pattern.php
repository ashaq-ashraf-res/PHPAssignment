<?php
// TODO: Implement function for nested pattern

<?php
// TODO: Implement function for is lowercase

<?php
// TODO: Implement function for palindrome check
